
import collections
import math
import random
import util
from engine.const import Const
from util import Belief


# Class: ExactInference
# ---------------------
# Maintain and update a belief distribution over the probability of a car
# being in a tile using exact updates (correct, but slow times).
class ExactInference:

    # Function: Init
    # --------------
    # Constructor that initializes an ExactInference object which has
    # numRows x numCols number of tiles.
    def __init__(self, numRows: int, numCols: int):
        self.skipElapse = False  ### ONLY USED BY GRADER.PY in case problem 2 has not been completed
        # util.Belief is a class (constructor) that represents the belief for a single
        # inference state of a single car (see util.py).
        self.belief = util.Belief(numRows, numCols)
        self.transProb = util.loadTransProb()

    ##################################################################################
    # Problem 1:
    # Function: Observe (update the probabilities based on an observation)
    # -----------------
    # Takes |self.belief| -- an object of class Belief, defined in util.py --
    # and updates it in place based on the distance observation $d_t$ and
    # your position $a_t$.
    #
    # - agentX: x location of your car (not the one you are tracking)
    # - agentY: y location of your car (not the one you are tracking)
    # - observedDist: true distance plus a mean-zero Gaussian with standard
    #                 deviation Const.SONAR_STD
    #
    # Notes:
    # - Convert row and col indices into locations using util.rowToY and util.colToX.
    # - util.pdf: computes the probability density function for a Gaussian
    # - Although the gaussian pdf is symmetric with respect to the mean and value,
    #   you should pass arguments to util.pdf in the correct order
    # - Don't forget to normalize self.belief after you update its probabilities!
    ##################################################################################

    def observe(self, agentX: int, agentY: int, observedDist: float) -> None:
        # BEGIN_YOUR_CODE
        for row in range(self.belief.getNumRows()):
            for col in range(self.belief.getNumCols()):
                # Convert tile (row, col) to (x, y) coordinates
                tileX = util.colToX(col)
                tileY = util.rowToY(row)
                # Compute Euclidean distance between agent and tile
                trueDistance = math.sqrt((agentX - tileX) ** 2 + (agentY - tileY) ** 2)
                # Compute emission probability using Gaussian PDF
                emissionProb = util.pdf(trueDistance, Const.SONAR_STD, observedDist)
                # Get current belief probability
                currentProb = self.belief.getProb(row, col)
                # Update belief: P(C | D_1, ..., D_t) \propto P(C | D_1, ..., D_{t-1}) * p(D_t | C)
                newProb = currentProb * emissionProb
                self.belief.setProb(row, col, newProb)
        # Normalize the belief to ensure probabilities sum to 1
        self.belief.normalize()
        # END_YOUR_CODE

    ##################################################################################
    # Problem 2:
    # Function: Elapse Time (propose a new belief distribution based on a learned transition model)
    # ---------------------
    # Takes |self.belief| and updates it based on the passing of one time step.
    # Notes:
    # - Tile coordinates are represented as (row, col) tuples
    # - Use the transition probabilities in self.transProb, which is a dictionary
    #   containing all the ((oldTile, newTile), transProb) key-val pairs that you
    #   must consider
    # - If there are ((oldTile, newTile), transProb) pairs not in self.transProb,
    #   they are assumed to have zero probability, and you can safely ignore them.
    # - Use the addProb (or setProb) and getProb methods of the Belief class to modify
    #   and access the probabilities associated with a belief.  (See util.py.)
    # - Be careful that you are using only the CURRENT self.belief distribution to compute
    #   updated beliefs.  Don't incrementally update self.belief and use the updated value
    #   for one grid square to compute the update for another square.
    # - Don't forget to normalize self.belief after all probabilities have been updated!
    #   (so that the sum of probabilities is exactly 1 as otherwise adding/multiplying
    #    small floating point numbers can lead to sum being close to but not equal to 1)
    ##################################################################################
    def elapseTime(self) -> None:
        if self.skipElapse: ### ONLY FOR THE GRADER TO USE IN Problem 1
            return
        # BEGIN_YOUR_CODE
        # Create a new Belief object to store updated probabilities
        newBelief = util.Belief(self.belief.getNumRows(), self.belief.getNumCols(), 0.0)
        
        # Iterate over all possible new tiles (newRow, newCol)
        for newRow in range(newBelief.getNumRows()):
            for newCol in range(newBelief.getNumCols()):
                newTile = (newRow, newCol)
                probSum = 0.0
                # Sum over all possible old tiles (oldRow, oldCol)
                for oldRow in range(self.belief.getNumRows()):
                    for oldCol in range(self.belief.getNumCols()):
                        oldTile = (oldRow, oldCol)
                        # Get transition probability from oldTile to newTile
                        transKey = (oldTile, newTile)
                        transProb = self.transProb.get(transKey, 0.0)
                        # Get current belief probability at oldTile
                        oldProb = self.belief.getProb(oldRow, oldCol)
                        # Add contribution: P(C_t | D_1, ..., D_t) * p(C_{t+1} | C_t)
                        probSum += oldProb * transProb
                # Set probability for newTile
                newBelief.setProb(newRow, newCol, probSum)
        
        # Normalize the new belief
        newBelief.normalize()
        # Update self.belief to the new belief
        self.belief = newBelief
        # END_YOUR_CODE

    # Function: Get Belief
    # ---------------------
    # Returns your belief of the probability that the car is in each tile. Your
    # belief probabilities should sum to 1.
    def getBelief(self) -> Belief:
        return self.belief